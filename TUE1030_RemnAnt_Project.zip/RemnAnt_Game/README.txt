Team RemnAnt

Ektoras Alexandrou (103980626) -- 3D and 2D Art and some programming
Finn Chandler (105344774) -- 3D Animation and UI
Amy Nguyen (105334607) -- Main programmer
Brandon Yu (105334555) -- Audio design, Music, and UI

ESC -- Pause screen with Controls listed.
W,A,S,D -- Moves the player.
C -- Super Jump button, once the ability is unlocked.
V -- Debug button, toggles access to the Super Jump ability, regardless of if you got it normally.
Mouse -- Look around.

Tools.
- Blender, Maya, Unity, Procreate, Discord, OneDrive, Github
Assets.
- Music by Brandon
- Art by Ektoras
- Animation by Finn
- Programming by Amy
- Unity Learn and Unity Documentation was used alot.

The ant's name is antonio.